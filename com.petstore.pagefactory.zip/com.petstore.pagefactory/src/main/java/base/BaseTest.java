package base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utils.ConfigReader;
import utils.DriverFactory;

public class BaseTest 
{
	
	 @BeforeMethod
	    public void setUp() {
	        DriverFactory.initDriver();
	        DriverFactory.getDriver().get(ConfigReader.getProperty("baseUrl"));
	    }

	    @AfterMethod
	    public void tearDown() {
	        DriverFactory.quitDriver();
	    }

}
